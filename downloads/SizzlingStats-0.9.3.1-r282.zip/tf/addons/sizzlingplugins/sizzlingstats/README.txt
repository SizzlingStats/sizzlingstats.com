SizzlingStats v0.9.3.1
July 3, 2013
by SizzlingCalamari, http://steamcommunity.com/groups/SizzlingPlugins

Round based stats plugin. Read about it in the group description in the link above.

CVars:
sizz_stats_version
 - The version of SizzlingStats running.

Installation Instructions:
	Merge main folder with srcds root directory.

	Restart your server and verify it is running by
	entering the command sizz_stats_version into the server console.

To correctly configure web stats, go to the config file 
located at
	tf/cfg/sizzlingplugins/sizzlingstats.cfg

For any comments, suggestions, or bugs, message me (SizzlingCalamari) in:
	http://steamcommunity.com/groups/SizzlingPlugins

Have fun.
